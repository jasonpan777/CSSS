import os
import pandas as pd
from sqlalchemy import create_engine, Column, String, Float, Integer, Date, ForeignKey
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
#此版本自带转换功能，转换txt文件的编码
def convert_to_utf8(file_path):
    with open(file_path, 'r', encoding='ansi') as file:
        content = file.read()
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(content)

def convert_folder_to_utf8(folder_path):
    # 遍历文件夹中的所有文件
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        if os.path.isfile(file_path) and filename.endswith('.txt'):
            convert_to_utf8(file_path)

# 使用方式：
# 设置要转换的文件夹路径
folder_path = 'E:\\StockData617'
# 调用函数进行转换
convert_folder_to_utf8(folder_path)
# 创建一个基础类
Base = declarative_base()

# 定义Stock类，用于创建stock表
class Stock(Base):
    __tablename__ = 'stock'
    CODE = Column(String, primary_key=True)  # 股票代码

# 定义HistoricalData类，用于创建historical_data表
class HistoricalData(Base):
    __tablename__ = 'historical_data'
    date = Column(Date, primary_key=True)  # 日期
    CODE = Column(String, ForeignKey('stock.CODE'), primary_key=True)  # 股票代码
    O = Column(Float)  # 开盘价
    H = Column(Float)  # 最高价
    L = Column(Float)  # 最低价
    C = Column(Float)  # 收盘价
    VOL = Column(Integer)  # 成交量
    turnover = Column(Float)  # 成交额

# 创建数据库引擎
engine = create_engine('sqlite:///stocks617.db')

# 创建所有表
Base.metadata.create_all(engine)

# 创建会话
Session = sessionmaker(bind=engine)
session = Session()

# 获取所有txt文件的路径(在指定目录下）
stock_files = [f for f in os.listdir('E:\\StockData617') if f.endswith('.txt')]

# 遍历所有txt文件
for stock_file in stock_files:
    try:
        # 从文件名获取股票代码和名称
        stock_code = stock_file.split('.')[0]

        # 读取txt文件的数据
        df = pd.read_csv(os.path.join('E:\\StockData617', stock_file), header=None, skiprows=2, skipfooter=1, engine='python',delimiter=',')
        df.columns = ['DATE', 'O', 'H', 'L', 'C', 'VOL', 'TURNOVER']

        # 添加股票到stock表
        new_stock = Stock(CODE=stock_code)  # 这里你需要根据实际情况提供股票名称
        session.add(new_stock)

        # 添加历史数据到historical_data表
        for index, row in df.iterrows():
            date = datetime.strptime(row['DATE'], '%Y-%m-%d')
            o, h, l, c, vol, turnover = row['O'], row['H'], row['L'], row['C'], row['VOL'], row['TURNOVER']
            new_data = HistoricalData(date=date, CODE=stock_code, O=o, H=h, L=l, C=c, VOL=vol, turnover=turnover)
            session.add(new_data)

        # 提交更改到数据库
        session.commit()
        #为了防止单个文件的脏数据导致整个工程结束，只要遇到错误，程序就会选择抛弃他
    except Exception as e:
        print(f"Error processing file {stock_file}: {e}")

