# 导入所需的库
import os
import pandas as pd
from sqlalchemy import create_engine, Column, String, Float, Integer, Date, ForeignKey
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import declarative_base  # 更改了对declarative_base的引用
from datetime import datetime
from tqdm import tqdm
import cchardet as chardet  # 新添加，用于检测文件编码

# 创建一个基础类
Base = declarative_base()

# 定义Stock类，用于创建stock表
class Stock(Base):
    __tablename__ = 'stock'  # 定义表名
    CODE = Column(String, primary_key=True)  # 定义CODE列，数据类型是字符串，是主键

# 定义HistoricalData类，用于创建historical_data表
class HistoricalData(Base):
    __tablename__ = 'historical_data'  # 定义表名
    # 定义各列，包括日期，股票代码，开盘价，最高价，最低价，收盘价，成交量和成交额
    date = Column(Date, primary_key=True)  # 日期列，数据类型是日期，是主键之一
    CODE = Column(String, ForeignKey('stock.CODE'), primary_key=True)  # 股票代码列，数据类型是字符串，是主键之一，同时是股票表的外键
    O = Column(Float)  # 开盘价列，数据类型是浮点数
    H = Column(Float)  # 最高价列，数据类型是浮点数
    L = Column(Float)  # 最低价列，数据类型是浮点数
    C = Column(Float)  # 收盘价列，数据类型是浮点数
    VOL = Column(Integer)  # 成交量列，数据类型是整数
    turnover = Column(Float)  # 成交额列，数据类型是浮点数

# 创建数据库引擎，连接到项目的DatabaseCreate目录下的stocks65.db数据库
engine = create_engine('sqlite:///stocks617.db')

# 创建会话
Session = sessionmaker(bind=engine)
session = Session()

# 定义更新数据库的函数，输入参数是股票文件的路径
def update_database(stock_file):
    try:
        # 从文件名获取股票代码
        stock_code = os.path.basename(stock_file).split('.')[0]

        # 读取txt文件的数据
        df = pd.read_csv(stock_file, header=None, skiprows=2, skipfooter=1, engine='python', delimiter=',')
        df.columns = ['DATE', 'O', 'H', 'L', 'C', 'VOL', 'TURNOVER']

        # 判断股票是否已在数据库中
        if session.query(Stock).filter(Stock.CODE == stock_code).count() == 0:
            # 如果股票未在数据库中，则添加
            new_stock = Stock(CODE=stock_code)
            session.add(new_stock)
        else:
            # 获取数据库中的最后日期
            last_date_in_db = session.query(HistoricalData.date).filter(HistoricalData.CODE == stock_code).order_by(HistoricalData.date.desc()).first()
            # 获取新数据的第一日期
            first_date_in_new_data = datetime.strptime(df['DATE'].iloc[0], '%Y-%m-%d').date() # convert to date object
            # 如果数据库中的最后日期在新数据的第一日期之后，删除数据库中从这个日期开始的数据
            if last_date_in_db and first_date_in_new_data <= last_date_in_db[0]:
                session.query(HistoricalData).filter(HistoricalData.CODE == stock_code, HistoricalData.date >= first_date_in_new_data).delete()

        # 添加历史数据到historical_data表
        for index, row in df.iterrows():
            date = datetime.strptime(row['DATE'], '%Y-%m-%d').date()  # convert to date object
            o, h, l, c, vol, turnover = row['O'], row['H'], row['L'], row['C'], row['VOL'], row['TURNOVER']
            new_data = HistoricalData(date=date, CODE=stock_code, O=o, H=h, L=l, C=c, VOL=vol, turnover=turnover)
            session.merge(new_data)

        # 提交更改到数据库
        session.commit()

    except Exception as e:
        print(f"Error processing file {stock_file}: {e}")

# 定义转换文件编码为utf8的函数，输入参数是文件路径
def convert_to_utf8(file_path):
    # 首先以二进制模式打开文件，读取原始数据
    with open(file_path, 'rb') as file:
        rawdata = file.read()
    # 使用chardet检测原始数据的编码
    result = chardet.detect(rawdata)
    encoding = result['encoding']

    # 使用检测到的编码打开文件，读取内容
    with open(file_path, 'r', encoding=encoding) as file:
        content = file.read()
    # 再以utf8编码写入文件
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(content)

# 定义转换文件夹中所有文件编码为utf8的函数，输入参数是文件夹路径
def convert_folder_to_utf8(folder_path):
    # 遍历文件夹中的所有文件
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        # 如果是txt文件，就转换编码
        if os.path.isfile(file_path) and filename.endswith('.txt'):
            convert_to_utf8(file_path)

# 使用方式：
# 设置要转换的文件夹路径
folder_path = 'E:\\StockData618'
# 调用函数进行转换
convert_folder_to_utf8(folder_path)
# 获取 "E:\\StockData" 目录下的所有文件
stock_files = [os.path.join('E:\\StockData618', f) for f in os.listdir('E:\\StockData618') if f.endswith('.txt')]

# 遍历所有文件，并对每个文件调用 `update_database` 函数
for stock_file in tqdm(stock_files, desc="Processing files", unit="file"):
    update_database(stock_file)
